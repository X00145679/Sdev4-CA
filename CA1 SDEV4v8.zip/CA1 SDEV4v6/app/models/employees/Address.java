package models.employees;
import java.util.*;
import javax.persistence.*;
import io.ebean.*;
import play.data.format.*;
import play.data.validation.*;

@Entity
public class Address extends Model{
@Id
private Long id;

@Constraints.Required
private String address;

@OneToMany
private List<Employee> employee;


public  Address() {
}
             
public  Address(Long id, String address, List<Employee> employee) {
   this.id = id;
   this.address = address;
   this.employee = employee;
}

public static Map<String,String> options() {
 LinkedHashMap<String,String> options = new LinkedHashMap();

 
 for (Address c: Address.findAll()) {
    options.put(c.getId().toString(), c.getAddress());
 }
 return options;
}

public void setId(Long id){
    this.id=id;
}

public void setAddress(String address){
    this.address=address;
}

public void setEmployees(List<Employee> employee){
    this.employee=employee;
}

public Long getId(){
    return id;
}

public String getAddress(){
    return address;
}

public List<Employee> getEmployee(){
    return employee;
}



public static Finder<Long,Address> find = new Finder<Long,Address>(Address.class);


public static List<Address> findAll() {
return Address.find.query().where().orderBy("address asc").findList();
}


}