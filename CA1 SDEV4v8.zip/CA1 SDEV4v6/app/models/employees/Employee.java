package models.employees;
import java.util.*;
import javax.persistence.*;
import io.ebean.*;
import play.data.format.*;
import play.data.validation.*;

@Entity
public class Employee extends Model {

    // Properties
    @Id
    private Long id;
    @Constraints.Required
    private String name;
    @Constraints.Required
    private String description;
    @Constraints.Required
    private int age;
    
    @ManyToMany(cascade = CascadeType.ALL, mappedBy = "employees")
    private List<Project> projects;

    @ManyToOne
    private Department department;

    @ManyToOne
    private Address address;

    private List<Long> projSelect = new ArrayList<Long>();

    
    public Employee() {
    }

    
    public Employee(Long id, String name, String description, int age) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.age = age;
        
    }

    public static final Finder<Long, Employee> find = new Finder<>(Employee.class);
			    
    public static final List<Employee> findAll() {
       return Employee.find.all();
        }

 
    
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public void setDescription(String description){
        this.description = description;
    }
    public String getDescription(){
        return description;
    }
    public int getAge(){
        return age;
    }
    public void setAge(int age){
        this.age=age;
    }
   
    public List<Project> getProjects(){
        return projects;
    }
    public void setProjects(List<Project> projects){
        this.projects=projects;
    }

    public List<Long> getProjSelect() {
        return projSelect;
    }
    public void setProjSelect(List<Long> projSelect) {
        this.projSelect = projSelect;
    }

    public void setDepartment(Department department){
        this.department=department;
    }

    public Department getDepartment(){
        return department;
    }

    public void setAddress(Address address){
        this.address=address;
    }

    public Address getAddress(){
        return address;
    }
}