package controllers;

import play.mvc.*;
import play.mvc.Http.*;
import play.mvc.Http.MultipartFormData.FilePart;
import java.io.File;
import java.io.IOException;
import java.awt.image.*;
import javax.imageio.*;
import org.imgscalr.*;
import views.html.*;
import play.api.Environment;
import play.data.*;
import play.db.ebean.Transactional;

import java.util.ArrayList;
import java.util.List;
import javax.inject.Inject;

import models.*;
import models.users.*;
import models.employees.*;

public class HomeController extends Controller {

    
    private FormFactory formFactory;
    private Environment e;
    @Inject
    public HomeController(FormFactory f, Environment env){
        this.e = env;
        this.formFactory=f;
    }



    public Result index() {
        return ok(index.render(User.getUserById(session().get("email"))));
    }

    public Result employee(Long cat) {
        List<Employee> employeeList = null;
        List<Project> projectList = Project.findAll();

        if(cat==0){
            employeeList = Employee.findAll();
        }else{
            employeeList= Project.find.ref(cat).getEmployees();
        }
        return ok(employee.render(employeeList, projectList,User.getUserById(session().get("email")),e));
        
     }

     public Result display(Long id) {
        List<Employee> employeeList =  null;
        employeeList = Employee.findAll();

        ArrayList<Employee> emp= new ArrayList<Employee>();
        
        for(int i=0;i<employeeList.size();i++){
            if(id == employeeList.get(i).getId()){
                emp.add(employeeList.get(i));
        } }
        return ok(display.render(emp,User.getUserById(session().get("email")),e));
   
     }

     

     public Result projects() {
        
        List<Project> projectList = Project.findAll();
        return ok(projects.render(projectList,User.getUserById(session().get("email")),e));
        
     }

    @Security.Authenticated(Secured.class)
    @With(AuthAdmin.class)
    public Result addEmployee() {
        Form<Employee> employeeForm = formFactory.form(Employee.class);
        return ok(addEmployee.render(employeeForm,User.getUserById(session().get("email"))));
    }

    @Security.Authenticated(Secured.class)
    @With(AuthAdmin.class)
    @Transactional
    public Result deleteEmployee(Long id){
        Employee.find.ref(id).delete();
        flash("success", "Employee has been deleted.");
        return redirect(controllers.routes.HomeController.employee(0));
    }

    @Security.Authenticated(Secured.class)
    @With(AuthAdmin.class)
    @Transactional
    public Result addEmployeeSubmit() {
        Form<Employee> newEmployeeForm = formFactory.form(Employee.class).bindFromRequest();
        if(newEmployeeForm.hasErrors()){
            return badRequest(addEmployee.render(newEmployeeForm,User.getUserById(session().get("email"))));
        }
        else{
            Employee newEmployee = newEmployeeForm.get();

            List<Project> newProjs = new ArrayList<Project>();
        for (Long proj : newEmployee.getProjSelect()) {
            newProjs.add(Project.find.byId(proj));
        }
        newEmployee.setProjects (newProjs);

            if(newEmployee.getId()==null){
                newEmployee.save();
            }else{
                newEmployee.update();
            }
    
            MultipartFormData<File> data = request().body().asMultipartFormData();
            FilePart<File> image = data.getFile("upload");
            String saveImageMessage = saveFile(newEmployee.getId(),image);
            flash("success", "Employee " + newEmployee.getName() + " was added/updated." +saveImageMessage);
            return redirect(controllers.routes.HomeController.employee(0));
        }
    }

    @Security.Authenticated(Secured.class)
    public Result updateEmployee(Long id){
        Employee i;
        Form<Employee> employeeForm;
        try{
            i = Employee.find.byId(id);
            employeeForm = formFactory.form(Employee.class).fill(i);
        } catch (Exception ex){
            return badRequest("error");
        }
        return ok(addEmployee.render(employeeForm,User.getUserById(session().get("email"))));

    }


    @Security.Authenticated(Secured.class)
    @Transactional
    @With(AuthAdmin.class)
    public Result deleteAdmin(String email) {
    
        
        Administrator u = (Administrator) User.getUserById(email);
        u.delete();
    
        flash("success", "User has been deleted.");
        return redirect(controllers.routes.HomeController.usersAdmin());
    }
    @Security.Authenticated(Secured.class)
    public Result updateAdmin(String email) {
        Administrator u;
        Form<Administrator> userForm;
    
        try {
            u = (Administrator)User.getUserById(email);
            u.update();
    
            userForm = formFactory.form(Administrator.class).fill(u);
        } catch (Exception ex) {
            return badRequest("error");
        }
    
        return ok(addAdmin.render(userForm,User.getUserById(session().get("email"))));
    }
    
    @Security.Authenticated(Secured.class)
    public Result addAdmin() {
        Form<Administrator> userForm = formFactory.form(Administrator.class);
        return ok(addAdmin.render(userForm,User.getUserById(session().get("email"))));
    }
    @Security.Authenticated(Secured.class)
    @Transactional
    public Result addAdminSubmit() {
    Form<Administrator> newUserForm = formFactory.form(Administrator.class).bindFromRequest();
    if (newUserForm.hasErrors()) {
        
        return badRequest(addAdmin.render(newUserForm,User.getUserById(session().get("email"))));
    } else {
        Administrator newUser = newUserForm.get();
        System.out.println("Name: "+newUserForm.field("name").getValue().get());
        System.out.println("Email: "+newUserForm.field("email").getValue().get());
        System.out.println("Password: "+newUserForm.field("password").getValue().get());
        System.out.println("Role: "+newUserForm.field("role").getValue().get());
        
        if(User.getUserById(newUser.getEmail())==null){
            newUser.save();
        }else{
            newUser.update();
        }
        flash("success", "User " + newUser.getName() + " was added/updated.");
        return redirect(controllers.routes.HomeController.usersAdmin()); 
        }
    }
    @Security.Authenticated(Secured.class)
    public Result addWorker() {
        Form<Worker> cForm = formFactory.form(Worker.class);
        return ok(addWorker.render(cForm,User.getUserById(session().get("email"))));
    }
    @Security.Authenticated(Secured.class)
    @Transactional
    public Result addWorkerSubmit() {
    Form<Worker> newUserForm = formFactory.form(Worker.class).bindFromRequest();
    if (newUserForm.hasErrors()) {
        
        return badRequest(addWorker.render(newUserForm,User.getUserById(session().get("email"))));
    } else {
        Worker newUser = newUserForm.get();
        System.out.println("Name: "+newUserForm.field("name").getValue().get());
        System.out.println("Email: "+newUserForm.field("email").getValue().get());
        System.out.println("Password: "+newUserForm.field("password").getValue().get());
        System.out.println("Role: "+newUserForm.field("role").getValue().get());
        
        if(User.getUserById(newUser.getEmail())==null){
            newUser.save();
        }else{
            newUser.update();
        }
        flash("success", "User " + newUser.getName() + " was added/updated.");
        return redirect(controllers.routes.HomeController.usersWorker()); 
        }
    }
    @Security.Authenticated(Secured.class)
    @Transactional
    @With(AuthAdmin.class)
    public Result deleteWorker(String email) {
    
        
        Worker u = (Worker) User.getUserById(email);
        u.delete();
    
        flash("success", "User has been deleted.");
        return redirect(controllers.routes.HomeController.usersWorker());
    }
    @Security.Authenticated(Secured.class)
    public Result updateWorker(String email) {
        Worker u;
        Form<Worker> userForm;
    
        try {
            u = (Worker) User.getUserById(email);
            u.update();
    
            userForm = formFactory.form(Worker.class).fill(u);
        } catch (Exception ex) {
            return badRequest("error");
        }
    
        return ok(addWorker.render(userForm,User.getUserById(session().get("email"))));
    }
    public Result usersAdmin() {
        List<Administrator> userList = null;
    
        userList = Administrator.findAll();
    
        return ok(admin.render(userList,User.getUserById(session().get("email"))));
    
     }
    
     public Result usersWorker() {
        List<Worker> cList = null;
    
        cList = Worker.findAll();
    
        return ok(workers.render(cList,User.getUserById(session().get("email"))));
    
     }

public String saveFile(Long id,FilePart<File> uploaded){

    if(uploaded!=null) {

        String mimeType = uploaded.getContentType();
        if(mimeType.startsWith("image/")) {
            String fileName = uploaded.getFilename();
            String extension = "";
            int i = fileName.lastIndexOf('.');
            if(i>=0){
                extension = fileName.substring(i+1);
            }
            File file = uploaded.getFile();
            File dir = new File("public/images/productImages");
            if(!dir.exists()){
                dir.mkdirs();
            }

            File newFile = new File("public/images/productImages/", id+ "." + extension);
            try{
                BufferedImage img = ImageIO.read(newFile);
                BufferedImage scaledImg = Scalr.resize(img,90);

                if(ImageIO.write(scaledImg, extension, new File("public/images/productImages/",id + "thumb.jpg"))) {
                    return "/ file uploaded and thumbnail created.";
                } else {
                    return "/ file uploaded but creation failed";
                }}catch (IOException e){
                return "/file uploaded but thumbnail creation failed.";
            }
        } else {
     return "/ file upload failed";
    }
 } return "/ no image file.";
 }
   

 @Security.Authenticated(Secured.class)
    @With(AuthAdmin.class)
    public Result addProject() {
        Form<Project> projectForm = formFactory.form(Project.class);
        return ok(addProject.render(projectForm,User.getUserById(session().get("email"))));
    }

    @Security.Authenticated(Secured.class)
    @With(AuthAdmin.class)
    @Transactional
    public Result deleteProject(Long id){
        Project.find.ref(id).delete();
        flash("success", "Project has been deleted.");
        return redirect(controllers.routes.HomeController.employee(0));
    }

    @Security.Authenticated(Secured.class)
    @With(AuthAdmin.class)
    @Transactional
    public Result addProjectSubmit() {
        Form<Project> newProjectForm = formFactory.form(Project.class).bindFromRequest();
        if(newProjectForm.hasErrors()){
            return badRequest(addProject.render(newProjectForm,User.getUserById(session().get("email"))));
        }
        else{
            Project newProject = newProjectForm.get();

            
            if(newProject.getId()==null){
                newProject.save();
            }else{
                newProject.update();
            }

            
            flash("success", "Project " + newProject.getName() + " was added/updated.");
            return redirect(controllers.routes.HomeController.employee(0));
        }
    }

    @Security.Authenticated(Secured.class)
    public Result updateProject(Long id){
        Project i;
        Form<Project> projectForm;
        try{
            i = Project.find.byId(id);
            projectForm = formFactory.form(Project.class).fill(i);
        } catch (Exception ex){
            return badRequest("error");
        }
        return ok(addProject.render(projectForm,User.getUserById(session().get("email"))));

    }

}
