# --- Sample dataset
 
# --- !Ups


 
delete from project_employee;
delete from employee;
delete from project;
delete from department;
delete from address;
insert into department(id,name) values (1,'Gaming');
insert into department(id,name) values (2,'Website');
insert into department(id,name) values (3,'Security');

insert into address(id,address) values (1,'17 Old Court Close Firhouse D24');
insert into address(id,address) values (2,'10 Old Court Close Firhouse D24');
insert into address(id,address) values (3,'11 Old Court Close Firhouse D24');

 
insert into project (id,name) values ( 1,'Game' );
insert into project (id,name) values ( 2,'Whiskey Store' );
insert into project (id,name) values ( 3,'Anti Virus' );

 
insert into employee (id,department_id,address_id,name,description,age) values ( 1,1,1,'Dave','Manager',20 );
insert into employee (id,department_id,address_id,name,description,age) values ( 2,2,2,'Steve','Cleaner',21 );
insert into employee (id,department_id,address_id,name,description,age) values ( 3,3,3,'Steve2','Janitor',21 );

insert into PROJECT_EMPLOYEE(project_id,employee_id) values (1,1);
insert into PROJECT_EMPLOYEE(project_id,employee_id) values (2,2);
insert into PROJECT_EMPLOYEE(project_id,employee_id) values (3,3);