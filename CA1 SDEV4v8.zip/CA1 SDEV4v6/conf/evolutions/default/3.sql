delete from user;

insert into user (type,email,role,name,password) values ( 'a','admin@admin.com','admin','Dave Admin', 'password');

